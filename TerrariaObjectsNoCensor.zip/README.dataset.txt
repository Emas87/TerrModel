# TerrariaObjects > 2023-05-08 12:02pm
https://universe.roboflow.com/tec-h4jb3/terrariaobjects

Provided by a Roboflow user
License: MIT

